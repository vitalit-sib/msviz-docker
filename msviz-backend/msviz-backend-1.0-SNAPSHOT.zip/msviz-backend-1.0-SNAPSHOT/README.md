# msViz Backend
A mass spectrometry visualization platform, developed by the PAF & Vital-IT, SIB Swiss Institute of Bioinformatics.


Visit the [wiki page](../../wiki) to have more details.

## Copyright
Copyright (C) 2014-2015 by Roman Mylonas (roman.mylonas@isb-sib.ch), Trinidad Martin (trinidad.martin@isb-ib.ch) and Alexandre Masselot (alexandre.masselot@isb-sib.ch), SIB Swiss Institute of Bioinformatics.


## Licensing

This program is available under the GNU General Public License (GPL,
version 2 or later; see below).

For users who need rights that go beyond what is allowed under the
GNU GPL (e.g. commercial or production use), it can be licensed under other terms.
Please contact <info@isb-sib.ch> for more information.

---
This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

